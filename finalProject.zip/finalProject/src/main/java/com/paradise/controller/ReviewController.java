package com.paradise.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.paradise.entity.Review;
import com.paradise.service.ReviewService;

@CrossOrigin(origins="http://localhost:3000/")
@RestController
@RequestMapping("/review")
public class ReviewController {

	@Autowired
	private ReviewService reviewService;

	@GetMapping("/find.paradise")
	List<Review> allReviewsController(){
		return reviewService.fetchAllReview();
	}

	@GetMapping("/find.paradise/{visitorId}")
	List<Review> reviewController(@PathVariable(value="visitorId") int visitorId){
		return reviewService.fetchReview(visitorId);
	}


	@PostMapping("/addReview.paradise/{username}")
	String reviewAdditionController(@PathVariable(value="username") String username,@RequestBody Review review) {
		System.out.println("patilji don"+review.getDescription());
		return reviewService.addReview(username, review);
	}

	@DeleteMapping("/delete.paradise/{id}")
	String reviewDeletionController(@PathVariable(value="id") int reviewId) {

		return reviewService.removeReview(reviewId);

	}

}